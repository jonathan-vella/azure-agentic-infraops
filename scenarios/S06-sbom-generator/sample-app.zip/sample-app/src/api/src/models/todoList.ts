export type TodoList = {
    id: string
    name: string
    description?: string
    createdDate?: Date
    updatedDate?: Date
}